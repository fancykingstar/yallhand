> Welcome to your team! We're happy to see you here ✨

# First steps to set up

-   [x] Create your Slite account 🙌

Organize your documentation

-   [ ] Divide up your knowledge by teams and projects with channels.

![](https://storage.googleapis.com/slite-api-files-production/files/fab15a51-e2f9-4b60-b1a1-3f8b0519c996/Channel_creation_welcome_note.gif)

﻿



Start documenting

-   [ ] Create your first note with rich content.

![](https://storage.googleapis.com/slite-api-files-production/files/516d7c1c-1c8a-4699-975c-8b2a4deea8d1/note-creation2.gif)

**Collaborate**

-   [ ] Invite teammates to discover Slite with you.

Stay synced with the apps:

-   [Mac](https://slite.com/api/desktop/download?platform=mac) & [Windows](https://slite.com/api/desktop/download?platform=win) 
-   [iOS](https://itunes.apple.com/app/apple-store/id1342934691?pt=118965043&ct=get-started-note&mt=8&ls=1) & [Android](https://play.google.com/store/apps/details?id=com.slite.mobile&referrer=utm_source%3Dget-started-note%26utm_medium%3Dlink%26utm_campaign%3Dget-started-note)

> _Questions? Check out the _
>
> `?`
>
> _ on the bottom right!_
